echo -e "\e[1;33m Kích hoạt nekobox...\e[0m"
sleep 0.95
echo -e "\e[1;32m Còn 3 giây...\e[0m"
sleep 0.95
echo -e "\e[1;32m Còn 2 giây...\e[0m"
sleep 0.95
echo -e "\e[1;32m Còn 1 giây...\e[0m"
sleep 0.15
clear